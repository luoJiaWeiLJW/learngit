import React, {Component} from 'react';
import {Modal,Button,Input,Select,message,TreeSelect} from 'antd';
import axios from 'axios';
import './style.css'
const  TextArea  = Input;
const Option = Select.Option;
const TreeNode = TreeSelect.TreeNode;
class ModalForm3 extends Component {
    constructor(props) {
        super(props);
        const visible=this.props.visible;
        this.state={
            treeData:[],
            codeData:[],
            onBlur:false,

        }
    }
    componentDidMount = () => {
        axios({
            url: '/tree/material_category/pid/0/children',
            method: 'get'
        }).then(res => {

            if (res.data.code !== "200") {
                message.success('网络异常,请稍后重试');
                return
            }
            const treeData = (res.data.data ? res.data.data : []);
            this.setState({
                treeData,
            })
        }).catch(e => {
            message.warning('网络异常,请稍后重试');
        })
    };
    handleCancel = (e) => {
        this.props.onCancel();
    }
    handleOk = (e) => {
        console.log(e);
        this.setState({
            visible: false,
        });
    }
    //查询数据
    search=(e)=>{

        this.setState({
            codeData:[],
        })
        if(e.target.value!=''){
            axios({
                url: '/keyword/'+e.target.value+'/materials',
                method: 'get',
                params: {
                    keyword:e.target.value,
                }
            }).then(res=>{
                this.setState({
                    codeData:res.data.data,
                })
                console.log(res.data.data)
            })
        }

    }
    //获得焦点
    onFocus=()=>{
        this.setState({
            onBlur:true,
        })
        console.log(this.state.onBlur)
    }
    //失去焦点
    onBlur=()=>{
        // this.setState({
        //     onBlur:false,
        // })
    }
    Select=(e)=>{
        let string="";
        let String=e.target;
        console.log(String)
        this.refs.Inputs.refs.input.value=e.target;

        console.log(e)
         this.setState({
             onBlur:false,
         })
    }
    dropDown=(codeData)=>{
        return(
            codeData.map((item,index)=>{
                return(
                    <li key= {index} ref= {'Pag'+index} onClick={this.Select.bind(this)}>{item.code}</li>
                )
            })
        )
    }


    render(){
        const {treeData,codeData}=this.state;
        const {visible}=this.props.visible
        console.log(codeData)
        const repeat = data => data.map((item) => {
            let child = [];
            if (!item.children) {
                return <TreeNode title={item.name} key={item.id} value={item.id}/>;
            }
            return <TreeNode title={item.name} key={item.id} value={item.id}>{repeat(item.children, child)}</TreeNode>;
        });
        return(
            <Modal
                visible={this.props.visible}
                title={[
                    <span style={{marginLeft:'430px',fontSize:'23px'}} key='exid'>变更物料</span>,
                ]}
                style={{minWidth: 1000}}
                onOk={this.handleOk}
                onCancel={this.handleCancel}
                footer={[
                    <span className='Change' key='Change' >变更说明:</span>,
                    <TextArea type='textarea' key='TextArea1' className='TextArea1' rows={4}/>,
                    <Button key="submit"  className='Preservation'>保存</Button>,
                    <Button key="back"  className='Cancel'onClick={this.handleCancel} >取消</Button>
                ]}
            >
                <div className='Idinput'>
                    <span className='Materialid'>物料编码:</span>

                    <Input placeholder='请输入物料编码'
                           onChange={this.search.bind(this)}
                           onFocus={this.onFocus}
                           onBlur={this.onBlur}
                           ref='Inputs'
                           className='Input'/>
                    <Button   className='Determine'>确定</Button>
                    <ul className='CodeData' style={{display:this.state.onBlur?'block':'none'}}>
                        {this.dropDown(codeData)}
                    </ul>
                </div>
                <div className='Content'>
                    <div className='Title-Materialid'>
                        <span className='Materialid'>*物料编码:</span>
                        <Input  className='Coding' disabled /> <Input  className='Coding1'  />
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid'>*物料名称:</span>
                        <Input  className='Coding' disabled /> <Input  className='Coding1'  />
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid'>*物料分类:</span>
                        <Input  className='Coding' disabled />

                        <TreeSelect style={{width:'350px',height:'400px',marginLeft:'80px'}}>
                            {repeat(treeData)}
                        </TreeSelect>

                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid'>*规格型号:</span>
                        <Input  className='Coding' disabled /> <Input  className='Coding1'  />
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid' style={{width:'70.44px',testAlign:'right'}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*单位:</span>
                        <Input  className='Coding' disabled /> <Input  className='Coding1'  />
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid'>*配置属性:</span>
                        <Input  className='Coding' disabled />
                        <Select   className='Source'>
                            <Option value="jack">通用</Option>
                            <Option value="lucy">非通用</Option>
                        </Select>
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid' style={{width:'70.44px',testAlign:'right'}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*来源:</span>
                        <Input  className='Coding' disabled />
                        <Select   className='Source'>
                            <Option value="jack">外购</Option>
                            <Option value="lucy">自制</Option>

                        </Select>
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid'>&nbsp;加工类型:</span>
                        <Input  className='Coding' disabled />
                        <Select   className='Source'>
                            <Option value="jack" disabled>无匹配结果</Option>
                        </Select>
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid'>&nbsp;产品系列:</span> <Input  className='Coding' disabled />
                        <Select   className='Source'>
                            <Option value="jack" disabled>无匹配结果</Option>
                        </Select>
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid' style={{width:'70.44px',testAlign:'right'}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;颜色:</span>
                        <Input  className='Coding' disabled />
                        <Select   className='Source'>
                            <Option value="jack" disabled>无匹配结果</Option>
                        </Select>
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid' style={{width:'70.44px',testAlign:'right'}}>&nbsp;&nbsp;&nbsp;保质期:</span>
                        <Input  className='Coding' disabled />
                        <Select   className='Source'>
                            <Option value="jack" disabled>无匹配结果</Option>
                        </Select>
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid'>&nbsp;存放要求:</span>
                        <Input  className='Coding' disabled /> <Input  className='Coding1'  />
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid' style={{width:'70.44px',testAlign:'right'}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;产地:</span>
                        <Input  className='Coding' disabled />
                        <Select   className='Source'>
                            <Option value="jack" disabled>无匹配结果</Option>
                        </Select>
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid'>&nbsp;材质等级:</span>
                        <Input  className='Coding' disabled />
                        <Select   className='Source'>
                            <Option value="jack" disabled>无匹配结果</Option>
                        </Select>
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid'style={{marginLeft:'-13px'}}>&nbsp;半制品种类:</span>
                        <Input  className='Coding' disabled />
                        <Select   className='Source'>
                            <Option value="jack" disabled>无匹配结果</Option>
                        </Select>
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid'>&nbsp;油漆面积:</span>
                        <Input  className='Coding' disabled /> <Input  className='Coding1'  />
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid'>&nbsp;备注说明:</span>
                        <Input  className='Coding' disabled /> <Input  className='Coding1'  />
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid' style={{width:'70.44px',testAlign:'right'}}>&nbsp;&nbsp;&nbsp;&nbsp;旧编码:</span>
                        <Input  className='Coding' disabled /> <Input  className='Coding1'  />
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid' style={{marginLeft:'-25px'}}>&nbsp;&nbsp;&nbsp;&nbsp;ROHS属性:</span>
                        <Input  className='Coding' disabled /> <Input  className='Coding1'  />
                    </div>
                    <div className='Title-Materialid'>
                        <span className='Materialid' style={{width:'70.44px',testAlign:'right'}}>&nbsp;&nbsp;&nbsp;&nbsp;损耗性:</span>
                        <Input  className='Coding' disabled /> <Input  className='Coding1'  />
                    </div>




                </div>

            </Modal>
        )
    }
}
export default ModalForm3
