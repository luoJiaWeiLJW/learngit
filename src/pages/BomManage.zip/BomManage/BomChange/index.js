import React, {Component} from 'react';

class BomChange extends Component {
  render() {
    return <div>bom变更单</div>
  }

}

export default BomChange;