import React, {Component} from 'react';

class CreateBom extends Component {
  render() {
    return <div>bom创建</div>
  }

}

export default CreateBom;