import React, {Component} from 'react';

class Material extends Component {
  render() {
    return <div>Material</div>
  }

}

export default Material;