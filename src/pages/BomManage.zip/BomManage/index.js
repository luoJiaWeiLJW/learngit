import React, {Component} from 'react';

class BomManage extends Component {
  render() {
    return <div>{this.props.children}</div>
  }
}

export default BomManage;